﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kertausharjoituksia_loka_2020
{
    class Aliluokka : OsinAbstrakti
    {
        //public new virtual int luku;

        public override string Tulosta()
        {
            int arvo = 5;
            luku = arvo;
            Console.WriteLine(arvo);
            return "";
            
        }
        public override void AsetaLuku(int uusi)
        {
            
            luku = uusi;
        }
    }
}
