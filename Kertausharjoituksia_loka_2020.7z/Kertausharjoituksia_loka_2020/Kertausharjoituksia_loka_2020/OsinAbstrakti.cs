﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kertausharjoituksia_loka_2020
{
    // 1. Korjaa virheet
    abstract class OsinAbstrakti
    {
        public int luku;
        public OsinAbstrakti()
        {
            luku = 2;
        }

        public abstract string Tulosta();

        public virtual void AsetaLuku(int uusi)
        {
            luku = uusi - 1;
        }
    }
}
