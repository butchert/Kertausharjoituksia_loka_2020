﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kertausharjoituksia_loka_2020
{
    class OsinStaattinen
    {
        static int laskuri;

        public OsinStaattinen()
        {
            laskuri++;
        }

        public static double Kertolasku(int x, int y)
        {
            return x * y;
        }

        public string Tulosta()
        {
            return laskuri.ToString();
        }
    }
}
