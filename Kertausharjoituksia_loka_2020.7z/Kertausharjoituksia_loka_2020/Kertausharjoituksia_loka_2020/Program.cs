﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kertausharjoituksia_loka_2020
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Staattinen.Tulosta());
            OsinStaattinen osinstaattinen = new OsinStaattinen();
            Aliluokka aliluokka = new Aliluokka();
            OsinAbstrakti uusiabstrakti = new Aliluokka();

            Console.WriteLine(osinstaattinen.Tulosta());
            Console.WriteLine(aliluokka.Tulosta());
            aliluokka.AsetaLuku(int.Parse(Console.ReadLine()));


            // 1. Korjaa virheet tiedostoissa OsinAbstrakti.cs ja Staattinen.cs
            // 2. Käytä luokkaa Staattinen (tulosta luokan/olion metodien palauttama arvo, poislukien konstruktori)
            // 3. Käytä luokkaa OsinStaattinen (tulosta luokan/olion metodien palauttama arvo, poislukien konstruktori)
            // 4. Tee uusi luokka Aliluokka, joka perii OsinAbstrakti-luokan. 
            //    Korjaa syntyneet "virheet", käytä Aliluokan metodeita niin, että Tulosta-metodia käytettäessä tulostuu "5" luokan luku-kentän arvosta.
            //    Miten Aliluokassa saadaan korvattua metodi AsetaLuku? (toteuta myös)
        }
    }
}
