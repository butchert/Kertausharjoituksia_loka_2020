﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kertausharjoituksia_loka_2020
{
    // 1. Korjaa virheet, mutta älä poista static -termiä class:in edestä
    public static class Staattinen
    {
        static int laskuri;

        static Staattinen() // tämä aiheuttaa virheen
        {

        }

        public static double Kertolasku(int x, int y)
        {
            return x * y;
        }

        public static string Tulosta()
        {
            return laskuri.ToString();
        }

    }
}
